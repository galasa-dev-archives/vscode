package dev.galasa.simbank.manager.ghrekin;

public @interface CucumberTranslator {
    
}
