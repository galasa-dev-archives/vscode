/*
 * Licensed Materials - Property of IBM
 * 
 * (c) Copyright IBM Corp. 2019.
 */
package dev.galasa.simbank.manager.spi;

import dev.galasa.simbank.manager.ISimBankManager;

public interface ISimBankManagerSpi extends ISimBankManager {

}
